import CONFIG from './config';
import LANGUAGE from './language';
import ROUTES from './routes';

export {
  CONFIG,
  LANGUAGE,
  ROUTES,
};
