export default [
  {
    code: 'en', name: 'English', default: true,
  },
  {
    code: 'de', name: 'German',
  },
];
