export default {
  API_ROOT_PATH: "https://jsonplaceholder.typicode.com",

  FOOTER: {
    COMPANY_NAME: "Evamp & Saanga",
    COMPANY_URL: "https://evampsaanga.com/",
  },
};
