import user from './user';

export const action = {
  user
};