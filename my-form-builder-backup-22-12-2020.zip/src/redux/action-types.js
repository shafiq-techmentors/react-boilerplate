export default {
  USER: {
    CREATE: 'user/create',
    GET: 'user/get',
    GET_ALL: 'user/get_all',
    UPDATE: 'user/update',
    DELETE: 'user/delete',
  },
};
